/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatecommerce2.teste;

import br.com.fatecommerce2.model.Brand;
import br.com.fatecommerce2.model.Category;
import br.com.fatecommerce2.model.Product;
import br.com.fatecommerce2.util.ConnectionFactory;
import java.sql.Connection;

/**
 *
 * @author Aluno
 */
public class Main {
    public static void main(String[] args) {
       /* Category c1 = new Category();
        c1.setIdCategory(-10);
        c1.setNameCategory("Carne");
        c1.setDescriptionCategory("Coisa maravilhosa de comer, se mal passada!");
        System.out.println("Dados: ID " + c1.getIdCategory() + "\nNome: " + c1.getNameCategory() + "\n"
                            + "Descrição " + c1.getDescriptionCategory());
        
       Brand b1 = new Brand();
       b1.setIdBrand(12);
       b1.setNameBrand("Friboi");
       b1.setDescriptionBrand("Carnes de boi e vaca");
        System.out.println("Marca: ID: " + b1.getIdBrand() + "\n"
            + "nome: " + b1.getNameBrand() + "\n"
                + "Descrição: " + b1.getDescriptionBrand());
        
        Product  p1 = new Product();
         p1.setIdProduct(34);
         p1.setNameProduct("Picanha");
         p1.setDescriptionProduct("carne cara e boa");
         p1.setCostPriceProduct(50.0);
         p1.setSalePriceProduct(60.0);
         p1.setBrand(b1);
         p1.setCategory(c1);
         System.out.println("id: " + p1.getIdProduct() + "\n Name : " + p1.getNameProduct() +
                "\n Descriçao: " + p1.getDescriptionProduct() + "\n Preço: " + p1.getSalePriceProduct() +
                 "\nPreço de custo: " + p1.getCostPriceProduct() + "\n Marca: " + p1.getBrand().getNameBrand() +
                 "\n categoria: " + p1.getCategory().getNameCategory());
         
         */
         Connection conn = null;
       try{
       conn = ConnectionFactory.getConnection();
       System.out.println("Conectado com sucesso");
       }catch(Exception ex ){
       System.out.println("deu ruim");
       ex.printStackTrace();
       }
       
        
    }
}
