/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatecommerce2.model;

/**
 *
 * @author Aluno
 */
public class Category {
    private Integer idCategory;
    private String nameCategory;
    private String descriptionCategory;

    public Integer getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(Integer idCategory) {
        if(idCategory > 0)
            this.idCategory = idCategory;
        
        else
            System.out.println("Não são aceitos valores nulos no ID!");
    }

    public String getNameCategory() {
        return nameCategory;
    }

    public void setNameCategory(String nameCategory) {
        this.nameCategory = nameCategory;
    }

    public String getDescriptionCategory() {
        return descriptionCategory;
    }

    public void setDescriptionCategory(String descriptionCategory) {
        this.descriptionCategory = descriptionCategory;
    }
    
    
}
