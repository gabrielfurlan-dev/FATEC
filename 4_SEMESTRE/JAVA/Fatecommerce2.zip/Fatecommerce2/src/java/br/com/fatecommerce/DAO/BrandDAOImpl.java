/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatecommerce.DAO;

import br.com.fatecommerce2.model.Brand;
import br.com.fatecommerce2.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Aluno
 */
public  class BrandDAOImpl implements GenericDAO {
    
    private Connection conn;
    
    public BrandDAOImpl(){
     try{
     this.conn = ConnectionFactory.getConnection();
     System.out.println("Conectado com sucesso");
     }catch(Exception ex){
         System.out.println("Problemas ao conectar ao BD Eroo:" + ex.getMessage());
         ex.printStackTrace();
         }
    }

    @Override
    public Boolean save(Object object) {
        Brand brand = (Brand) object;
        PreparedStatement stmt = null;
        String sql = "INSERT INTO public.brand(name_brand, description_brand) VALUES (?,?);";
        
        try{
            
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, brand.getNameBrand());
        stmt.setString(2, brand.getDescriptionBrand());
        stmt.executeUpdate();
        return true;
        }
        catch(SQLException ex){
        System.out.println("Problemas ao cadastrar Brand! ERRO:" + ex.getMessage());
        ex.printStackTrace();
        return false;
        
        }
        finally{
           try{
               ConnectionFactory.closeConnection(conn, stmt);
               
           }catch(Exception ex){
               System.out.println("Problemas ao fechar conexão! ERRO:" + ex.getMessage());
               ex.printStackTrace();
                 }
              }
           }

    @Override
    public List<Object> findAll() {
        List<Object> marcas = new ArrayList<>();
       PreparedStatement stmt = null;
       ResultSet rs = null;
       String sql = "SELECT b.* FROM brand b ORDER BY b.name_brand;";
               
               try{
               stmt = conn.prepareStatement(sql);
               rs = stmt.executeQuery();
               
               while(rs.next()){
               Brand brand
               }
               
               }
    }

    @Override
    public void deleteByid(Integer idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object findByid(Integer idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
