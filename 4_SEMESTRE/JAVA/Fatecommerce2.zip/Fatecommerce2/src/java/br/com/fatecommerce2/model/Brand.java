/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatecommerce2.model;

/**
 *
 * @author Aluno
 */
public class Brand {
    /*Id deve ser entre 1 e 10 e o nome da marca
    deve ter pelo menos 2 caracteres*/
    
    private Integer idBrand;
    private String nameBrand;
    private String descriptionBrand;

    public Integer getIdBrand() {
        return idBrand;
    }

    public void setIdBrand(Integer idBrand) {
        this.idBrand = idBrand;
    }

    public String getNameBrand() {
        return nameBrand;
    }

    public void setNameBrand(String nameBrand) {
        this.nameBrand = nameBrand;
    }

    public String getDescriptionBrand() {
        return descriptionBrand;
    }

    public void setDescriptionBrand(String descriptionBrand) {
        this.descriptionBrand = descriptionBrand;
    }
    
    
}
